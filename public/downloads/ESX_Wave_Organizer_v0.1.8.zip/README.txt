---------------------------
  ESX Wave Organizer v0.1.8
---------------------------

website: http://www.skratchdot.com/esxwaveorganizer/home.php
contact: jastek25@hotmail.com


---> This README file was last edited on 07-17-05 <---


INFO
-------

No Installation Required.  Just unzip and run the .exe.




Known Bugs & Limitations
-------------------------

- Cannot edit the start, end, loop start, time slice and sample tune parameters.

- Some of these features will be added in future versions.... Check out the website for more info.




Version History
-------------------

v0.1 --- Initial Release (May 6, 2004)

v0.1.1 --- Released On May 9, 2004
  -- Fixed a bug that would ignore .wav files that had a 'smpl' chunk with the "number of samples value=0"
  -- Now when you double-click a sample in the list, it will simulate pressing the "Play" button.  You can
     still only "Play" samples that originate on your computer.

v0.1.2 --- Released On May 13, 2004
  -- Fixed a bug that would let you add a stereo sample when you shouldn't be able to.  This would cause
     the available memory to be negative, which should never happen.  Since stereo samples take up twice
     the memory that mono samples do, I was letting you add a stereo sample, without checking if twice it's
     size would fit.  For example, if your memory left was: 4000, and the stereo sample's memory size was 6000,
     it would still be added, because 3000 is less than 4000.  Your memory left would be -2000 after adding it.
     All this has been fixed, and hopefully no one ran into this problem....

v0.1.3 --- Released On October 29, 2004
  -- Added AIFF support.  The program will recognize 8 or 16 bit, mono or stereo, .aif files.
  -- Added Minimize and Maximize Buttons
  -- The Play and Loop buttons work for every sample now.  If you press the Loop button on a sample that is not a
     loop, it will play the whole sample repeatedly.
  -- Rearranged the main dialog.  Now the mono and stereo lists are side by side (displaying more samples at once).
  -- Got rid of the "quick save" buttons, and added regular "Windows style" open and save dialogs.
  -- Added a "Remove All Samples" feature, which deletes all the samples from the workspace, but leaves
     the pattern and song data that is loaded.
  -- Got rid of the file "esxwaveorganizer.data".  Now you only need the .exe file for the program to work.
  -- Fixed the "Clear Pattern & Song Data".  Previously, when you cleared all pattern data, each part's
     sample would be set to Mono Sample #000.  Now, when you clear all pattern data, and load an .esx file
     into your sampler, each parts' sample will be set to NONE (not Mono Sample #000).
  -- Added a Menu with the options:
     - File:
           * Open/Add Files To Workspace
           * Save As ESX File
           * Extract All Waves
           * Exit
     - Functions:
           * Clear All Pattern And Song Data
           * Pattern Organizer
           * Song Organizer
           * Remove All Samples
     - Help:
           * About ESX Organizer
           * Visit Website

v0.1.4 --- Released On November 17, 2004
  -- You can now view if a sample has been time sliced or not.
  -- You can now view and set the Play Level for each samples.
  -- BUG FIX == Before, if the focus was on Mono Sample 001, and you clicked on a "greyed" Stereo Sample 001, the
     focus would still be on Mono Sample 001.  This has been fixed.  No matter what sample you click on, it will
     always become the focus...
  -- BUG FIX == Before I accept an .esx file into the workspace, I do a few checks on the file.  It must contain
     the values "KORG" in 2 places; it must contain the value 0x71 in two places; and it must contain the value
     "ESX" in one place.  Previously, I was also making sure that it had the value "BPS" in one place.  This was not
     needed, and it was not true for all .esx files.  I found this out because someone emailed me saying that the
     program was not accepting their .esx file.  Where I thought that the value "BPS" was needed, it wasn't.  The
     .esx file in question, had the value "BPA" where I thought the value had to be "BPS".  If anyone else has a
     problem loading an .esx file into the workspace, email me... It is probably because one of the other checks
     I do is unneccessary.

v0.1.5BETA --- Released On December 1, 2004
  -- Added the "Pattern Editor" with limited functionality

v0.1.6 --- Released On June 17, 2005
  -- Fixed major "SLICE" problem.  Before, if you moved a sample that had been sliced 
     on the ESX, it would not play back properly without being "re-sliced".  This has now been fixed.
  -- Added "Set All Play Levels To" to the Functions menu.  This will let you set them 
     to either 0dB or +12dB.
  -- Fixed typos:
     * changed "Fuctions" to "Functions"
     * changed "Exit Part Editor" to "Exit Pattern Editor"

v0.1.7 --- Released On July 10, 2005
  -- Added a "first loading slot" feature.  Previously, all samples would try to load into slot #000.  If that was 
     already in use, it would find the next available slot.  Now, you can set the first slot number to try.  It will 
     then find the next available slot (looping around when it gets to the end).
  -- Changed the "About Box".  Now you can click on my email address to open your default email client to email me, 
     or click on the program's webpage url to open your default webbrowser and visit the homepage.
  -- Removed the "Push Up" and "Push Down" buttons (which weren't implemented), and replaced them with the "NEVER LOOP" 
     and "LOOP WHOLE" buttons.
  -- The "NEVER LOOP" button sets the sample's "Loop Start" value equal to the sample's "End" value.  This means that 
     the sample will never loop when played as a keyboard part.
  -- The "LOOP WHOLE" button sets the sample's "Loop Start" value equal to the sample's "Start" value.  This means that 
     the sample will loop completely when played as a keyboard part.
  -- The "LOOP" button will only work for MONO samples that have a "Loop Start" value.  If a sample doesn't have a 
     "Loop start" value (and you want to hear it loop), you can press the "LOOP WHOLE" button.  Now you can press the 
     "LOOP" button.
  -- Changed the "Extract All Waves" feature.  Before it would rename files with the sample name last.  Now it renames 
     them with the sample name first.  So,
     BEFORE:  "ESXextracted-MONO-140-M1PickBs.wav"
        NOW:  "M1PickBs-MONO-140-ESXextracted.wav"
  -- Changed the button name "Remove The Selected Wave" to "Remove The Selected Sample".
  -- Changed the button name "Edit The Selected Wave" to "Edit The Selected Sample".
  -- Added a "Convert Selected Sample (MONO/ST)" button.  This will convert a Mono Sample to a Stereo Sample, or a
     Stereo Sample to a Mono Sample (depending on what is selected, and how much free space there is).
  -- BUGFIX:  Before I was only accepting files with the extensions (.esx, .wav, and .aif).  I was ignoring all other
     files (including .aiff).  Now I am accepting .aiff as well as .aif, so: (.esx, .wav, .aif, and .aiff are all the 
     acceptable formats).  Thanks to Jayzilla for reporting this.
  -- Added a "Pattern List" Column in the Sample Organizers, which let you see what Patterns a Sample is used in.
  -- Added a "Remove All Samples Not Used In A Pattern" function.  This lets you free up space by removing any samples
     that aren't being used.
  -- Added a "Mono Organizer" function.  This opens up a new dialog window, which will let you select multiple samples,
     and move them around (by dragging them).  Hold down the shift button to select multiple samples.  You can rename
     multiple samples, and change their stretch step values.  If you check the "Add Number" box, then you can rename
     multiple samples, and a unique number will be added to the end of the sample name (for instance: if you type "bass",
     your samples will be renamed "bass0", "bass1", "bass2", etc.).

v0.1.8 --- Released On July 17, 2005
  -- BUGFIX:  Fixed a bug that was ignoring certain .aif/.aiff files.
  -- BUGFIX:  Fixed a CPU Memory Leak that occured when using the "Remove All Samples" Fuction.  Previously, I was only freeing CPU memory when using the "Remove Currently Selected Sample" or "Remove All Samples Not Used In A Pattern" Fuctions.  This could slow down your system (only while the program was running) if you repeatedly used the "Remove All Samples" Fuction in a session.
  -- BUGFIX:  Fixed a bug that was not displaying the STEREO Sample Names in the Pattern Organizer.
  -- BUGFIX:  Fixed another bug that was not always storing "SLICE" samples correctly.  Search the forums for more info about this bug.
  -- Changed the name of the "Pattern Organizer" to "Pattern Editor".
  -- Changed the name of the "Song Organizer" to "Song Editor".
  -- The Song Editor works now.
  -- Added Minimize/Maximize Buttons to the Pattern Editor and the Song Editor.



Notes
---------

Please visit the website at http://www.skratchdot.com/esxwaveorganizer/home.php
and sign up at the forum.  Let me know what you think...

