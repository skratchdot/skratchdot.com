------\(ES-1)step
---\-
-----\Copyright (c)2003
--
         jastek25@hotmail.com
-----------------------------
Purpose:

This program is a midi controller for the Korg ES-1 Electribe Sampler.

It allows you to give each midi key (up to 128 keys) ES-1 functionality.  Each key may be assigned
to a part on the ES1, and will loop through a 64 step pattern (at a specified BPM) while the midi key
is held down.  You may design your own presets.  Each step of the pattern accepts all the available ES1
parameters. You may also load random presets at any time.

-------------------

---------------------
Installing:

Just unzip the "ES1step.zip" file to a directory and run the file "ES1step.exe".

There are 5 files included in the .zip:

ES1step.exe
Pitch Shift - Audio In.preset
Pitch Shift - Part 1.preset
pm_dll.dll
README.txt

Everything should work fine.  I have a Pentium III 1000mhz processor and everything
runs with no lag time/latency time at all.  If anyone has any problems email me:

jastek25@hotmail.com


This program is distributed AS IS.  I cannot assume responsibility for any loss or damage related
to this application.

-----------------------------------------

------------------
Version History:

Version 0.1
-----------
First Release

Version 0.2
-----------
Pattern Settings Feature - Now you can set a starting and ending step, and also specify whether or
          not to loop through the pattern while you hold a key down, or just play the pattern once.

Random Generator Addition - Now you can toggle which effects the random generator can use.

Send These Parameters Function - Now you can select which parameters you want to send to the ES-1.
          If you want to manually tweak knobs on the ES-1, just use this function to deselect the
          right parameters.

Version 0.2.1
-------------
No install program in this version.  Just unzip it and run it.

Fixed a minor bug - In old versions, if ES1step could not find a midi input or output device, it would 
still ask you to enter a device number and then quit when it couldn't find the device.  Now it will
tell you to download MidiYOKE and MidiOX. ES1step will definately recognize MidiYoke's virtual ports.

Version 1.0.0 - FULL WINDOWS VERSION __BETA___
---------------
The program was pretty much completely rewritten.
New Features Include:
-- You can change Midi In and Midi Out devices at any time while running the program.
-- You can select different Channels for the midi in and out devices.
-- 3 different pattern modes, you can select the starting and ending steps for a pattern
-- You can load and save presets. (all preset files are 578KB big)
-- You can select which of the 17 different parameters to send to the ES-1.
-- You can select which Note Numbers control the different parts on the ES-1.
-- New Random Generator Features:
        * You can give an upper and lower bound for 17 different parameters, and select
          which effects and parts are allowed to be assigned.
-- Key Settings Dialog -- You can now edit patterns and all their parameters on screen.
-- Set all function which allows you to set every step for every key to a specified value.
-- Panic button which automatically turns off all the keys when it is hit.
-- New GUI

More features to come!!!

NOTE:  I've already made a keyboard mode function which (if you set parts 1 - 7 to the same sample)
       pitch maps the keys on the keyboard and allows you to play chords on your es-1.  You can also
       set attack and release times (fade in and fade out times).  I didn't include it, because there's
       still a few bugs with the attack and release times.

Known Bugs:
-----------
No known bugs, but as of right now the program can only recognize up to 16 midi in devices
and 16 midi out devices (32 midi devices total).

---------
Notes:

ES1step website:
  http://members.lycos.co.uk/es1step/index.html

ES1step was written with the help of the PortMIDI API available at:
  http://www.cs.cmu.edu/~music/portmidi/

If a certain midi device is not recognized by the program, try downloading:

MIDI Yoke and MIDI Ox from:
  http://www.midiox.com


It should recognize the MIDI Yoke virtual ports.  Open two instances of MIDI Ox and your on your way.

In ES1step: select input as MIDI Yoke Port 1
            select output as MIDI Yoke Port 2

In MIDI OX instance 1:  select input as (YOUR INPUT DEVICE)
                        select output as MIDI Yoke Port 1

In MIDI Ox instance 2:  select input as MIDI Yoke Port 2
                        select output as (YOUR OUTPUT DEVICE)

------------------------------------

Send comments, questions, suggestions, bug reports, and any thing else to:

jastek25@hotmail.com
